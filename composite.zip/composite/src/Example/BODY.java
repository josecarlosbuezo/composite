/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Example;

import CompositePattern.Composite;

/**
 *
 * 
 */
public class BODY extends Composite{
    public BODY(){
        super("BODY");
    }    
}
