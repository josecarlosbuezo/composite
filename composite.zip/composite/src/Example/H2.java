/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Example;

import CompositePattern.Leaf;

/**
 *
 * 
 */
public class H2 extends Leaf{
    public H2(String text){
        super("H2", text);
    }
}
