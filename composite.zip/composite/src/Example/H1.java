/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Example;

import CompositePattern.Leaf;

/**
 *
 * 
 */
public class H1 extends Leaf{
    public H1(String text){
        super("H1", text);
    }
}
