
package CompositePattern;

/**
 *
 * 
 */
public interface IComponent {
    // Common Operation
    void Print(int depth);
}
