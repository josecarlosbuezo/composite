
package CompositePattern;

import java.util.LinkedList;

/**
 *
 * 
 */
public class Composite implements IComponent {
    private final String _name;
    private final LinkedList<IComponent> _components;
    
    public Composite(String name){
        _name = name;
        _components = new LinkedList();
    }
    
    public void AddComponent(IComponent component){
        _components.add(component);
    }
    
    public void RemoveComponenet(IComponent component){
        _components.remove(component);
    }
    
    @Override
    public void Print(int depth) {
        int _depth = depth;
        String spaces = "";
        while(_depth-->0){
            spaces += " ";
        }
        
        System.out.println(String.format("%s<%s>", spaces, _name));
        
        for (IComponent c : _components){
            c.Print(depth + 4);
        }
        
        System.out.println(String.format("%s</%s>", spaces, _name));
    }
}
