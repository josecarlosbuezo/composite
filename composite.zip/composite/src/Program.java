
import Example.*;

/**
 *
 * 
 */
public class Program {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HTML html = new HTML();
        
        HEAD head = new HEAD();
        BODY body = new BODY();
        
        html.AddComponent(head);
        html.AddComponent(body);
        
        TITLE title = new TITLE("Hello Composite Pattern!");
        head.AddComponent(title);
        
        DIV div1 = new DIV();
        DIV div1Inner = new DIV();
        
        div1.AddComponent(div1Inner);
        
        DIV div2 = new DIV();
        
        H1 h1 = new H1("This is an H1 tag");
        div2.AddComponent(h1);
        
        body.AddComponent(div1);
        body.AddComponent(div2);

        html.Print(0);
    }
}
